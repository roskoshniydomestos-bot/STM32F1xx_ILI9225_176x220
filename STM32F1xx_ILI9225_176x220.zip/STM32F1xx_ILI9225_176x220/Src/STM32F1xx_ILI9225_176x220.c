/*
 * STM32F1xx_ILI9225_176x220.c
 *
 *  Created on: 13 мар. 2026 г.
 *      Author: user
 */

#include "STM32F1xx_ILI9225_176x220.h"

#include "stm_fount.h"

#include "main.h"
#include "stdint.h"
#include "stdbool.h"

struct SPI SPI;

void SPI_move(SPI_HandleTypeDef * hspi, uint8_t hByte, uint8_t lByte){
	HAL_SPI_Transmit(hspi, &hByte, 1, HAL_MAX_DELAY);
	HAL_SPI_Transmit(hspi, &lByte, 1, HAL_MAX_DELAY);
}

void setRegistor(SPI_HandleTypeDef * hspi, uint16_t reg_hex){
	uint8_t lByte = 0xFF & reg_hex;
	uint8_t hByte = 0xFF & (reg_hex >> 8);

	SPI_move(hspi,hByte ,lByte);
}

void setCommand(SPI_HandleTypeDef * hspi, uint16_t cmd_hex){
	uint8_t lByte = 0xFF & cmd_hex;
	uint8_t hByte = 0xFF & (cmd_hex >> 8);

	SPI_move(hspi,hByte ,lByte);
}

void set_ReC(SPI_HandleTypeDef * hspi, uint16_t reg_hex, uint16_t cmd_hex){
	HAL_GPIO_WritePin(SPI.CS_PORT, SPI.CS_PIN, GPIO_PIN_RESET);
	HAL_GPIO_WritePin(SPI.RS_PORT, SPI.RS_PIN, GPIO_PIN_RESET);

	setRegistor(hspi, reg_hex);

	HAL_GPIO_WritePin(SPI.RS_PORT, SPI.RS_PIN, GPIO_PIN_SET);
	setCommand(hspi, cmd_hex);

	HAL_GPIO_WritePin(SPI.CS_PORT, SPI.CS_PIN, GPIO_PIN_SET);
}

void LCD_Init(SPI_HandleTypeDef * hspi){
	HAL_GPIO_WritePin(SPI.RST_PORT, SPI.RST_PIN, GPIO_PIN_RESET);
	HAL_Delay(10);
	HAL_GPIO_WritePin(SPI.RST_PORT, SPI.RST_PIN, GPIO_PIN_SET);
	HAL_Delay(50);

	set_ReC(hspi, 0x0010, 0x0000);
	set_ReC(hspi, 0x0012, 0x0000);
	set_ReC(hspi, 0x0013, 0x0000);
	set_ReC(hspi, 0x0014, 0x0000);
	HAL_Delay(40);

	set_ReC(hspi, 0x0011, 0x0018);
	set_ReC(hspi, 0x0012, 0x6621);
	set_ReC(hspi, 0x0013, 0x006F);
	set_ReC(hspi, 0x0014, 0x495F);
	set_ReC(hspi, 0x0010, 0x0F00);
	HAL_Delay(10);

	set_ReC(hspi, 0x0011, 0x103B);
	HAL_Delay(50);

	set_ReC(hspi, 0x0001, 0x011C);
	set_ReC(hspi, 0x0002, 0x0100);
	set_ReC(hspi, 0x0003, 0x1030);
	set_ReC(hspi, 0x0007, 0x0000);
	set_ReC(hspi, 0x0008, 0x0808);
	set_ReC(hspi, 0x000B, 0x1100);
	set_ReC(hspi, 0x000C, 0x0000);
	set_ReC(hspi, 0x000F, 0x0F01);
	HAL_Delay(10);

	set_ReC(hspi, 0x0015, 0x0020);
	set_ReC(hspi, 0x0020, 0x0000);
	set_ReC(hspi, 0x0021, 0x0000);

	set_ReC(hspi, 0x0030, 0x0000);
	set_ReC(hspi, 0x0031, 0x00DB);
	set_ReC(hspi, 0x0032, 0x0000);
	set_ReC(hspi, 0x0033, 0x0000);
	set_ReC(hspi, 0x0035, 0x0000);
	set_ReC(hspi, 0x0036, 0x00AF);
	set_ReC(hspi, 0x0037, 0x0000);
	set_ReC(hspi, 0x0038, 0x00DB);
	set_ReC(hspi, 0x0039, 0x0000);

	set_ReC(hspi, 0x0050, 0x0000);
	set_ReC(hspi, 0x0051, 0x0808);
	set_ReC(hspi, 0x0052, 0x080A);
	set_ReC(hspi, 0x0053, 0x000A);
	set_ReC(hspi, 0x0054, 0x0A08);
	set_ReC(hspi, 0x0055, 0x0000);
	set_ReC(hspi, 0x0056, 0x0000);
	set_ReC(hspi, 0x0057, 0x0A00);
	set_ReC(hspi, 0x0058, 0x0710);
	set_ReC(hspi, 0x0059, 0x0710);

	set_ReC(hspi, 0x0007, 0x0012);
	HAL_Delay(50);
	set_ReC(hspi, 0x0007, 0x1017);
}

uint16_t RGB(uint8_t red8, uint8_t green8, uint8_t blue8) {
    return (red8 >> 3) << 11 | (green8 >> 2) << 5 | (blue8 >> 3);
}

void LCD_setPixel(SPI_HandleTypeDef * hspi, unsigned int x, unsigned int y, uint16_t color){
	set_ReC(hspi, 0x0020, x);
	set_ReC(hspi, 0x0021, y);
	set_ReC(hspi, 0x0022, color);
}

void LCD_charOut(SPI_HandleTypeDef * hspi, int64_t char_UTF_8, unsigned int x, unsigned int y, uint16_t charColor, uint16_t bkColor){
	bool buffer[MAX_CHAR_LINE_Y][MAX_CHAR_LINE_X] = {0};

	uint64_t _returnChar = returnChar(buffer, char_UTF_8);
	if(_returnChar == -1) _returnChar = returnChar(buffer, 0x0);

	for (unsigned int x_char = 0; x_char < MAX_CHAR_LINE_X; x_char++) {
		for (unsigned int y_char = 0; y_char < MAX_CHAR_LINE_Y; y_char++) {
			switch(buffer[y_char][x_char]){
			case 0: LCD_setPixel(hspi, x + x_char, y + y_char, bkColor);	break;
			case 1: LCD_setPixel(hspi, x + x_char, y + y_char, charColor);	break;
			}
		}
	}
}

void LCD_textOut(SPI_HandleTypeDef *hspi, unsigned int x, unsigned int y, char text[], unsigned int numCharInText, uint16_t charColor, uint16_t bkColor){
	for(unsigned int i = 0; i < numCharInText; i++){
		LCD_charOut(hspi, text[i], x + i * MAX_CHAR_LINE_X, y, charColor, bkColor);
	}
}

void swap(uint16_t *a, uint16_t *b) {
    uint16_t w = *a;
    *a = *b;
    *b = w;
}

void LCD_line(SPI_HandleTypeDef * hspi, uint16_t x1_u, uint16_t y1_u, uint16_t x2_u, uint16_t y2_u, uint16_t color){
    int32_t x1 = (int32_t)x1_u;
    int32_t y1 = (int32_t)y1_u;
    int32_t x2 = (int32_t)x2_u;
    int32_t y2 = (int32_t)y2_u;

    int32_t steep = abs(y2 - y1) > abs(x2 - x1);

    if (steep) {
        /* swap x и y */
        int32_t tmp;
        tmp = x1; x1 = y1; y1 = tmp;
        tmp = x2; x2 = y2; y2 = tmp;
    }

    if (x1 > x2) {
        int32_t tmp;
        tmp = x1; x1 = x2; x2 = tmp;
        tmp = y1; y1 = y2; y2 = tmp;
    }

    int32_t dx = x2 - x1;
    int32_t dy = abs(y2 - y1);
    int32_t err = dx / 2;
    int32_t ystep = (y1 < y2) ? 1 : -1;

    for (int32_t x = x1; x <= x2; x++) {
        if (steep) {
            LCD_setPixel(hspi, (uint16_t)y1, (uint16_t)x, color);
        } else {
            LCD_setPixel(hspi, (uint16_t)x, (uint16_t)y1, color);
        }

        err -= dy;
        if (err < 0) {
            y1 += ystep;
            err += dx;
        }
    }
}

void LCD_circle(SPI_HandleTypeDef * hspi, uint8_t x0, uint8_t y0, uint8_t r, uint16_t color) {
	int16_t f = 1 - r;
	    int16_t ddF_x = 1;
	    int16_t ddF_y = -2 * r;
	    int16_t x = 0;
	    int16_t y = r;

	    LCD_setPixel(hspi, x0, y0 + r, color);
	    LCD_setPixel(hspi, x0, y0 - r, color);
	    LCD_setPixel(hspi, x0 + r, y0, color);
	    LCD_setPixel(hspi, x0 - r, y0, color);

	    while (x < y) {
	        if (f >= 0) {
	            y--;
	            ddF_y += 2;
	            f += ddF_y;
	        }
	        x++;
	        ddF_x += 2;
	        f += ddF_x;

	        LCD_setPixel(hspi, x0 + x, y0 + y, color);
	        LCD_setPixel(hspi, x0 - x, y0 + y, color);
	        LCD_setPixel(hspi, x0 + x, y0 - y, color);
	        LCD_setPixel(hspi, x0 - x, y0 - y, color);
	        LCD_setPixel(hspi, x0 + y, y0 + x, color);
	        LCD_setPixel(hspi, x0 - y, y0 + x, color);
	        LCD_setPixel(hspi, x0 + y, y0 - x, color);
	        LCD_setPixel(hspi, x0 - y, y0 - x, color);
	    }
}
