#include "stm_fount.h"
#include "chars.h"

#include <stdint.h>
#include <stdbool.h>

void charCopy(bool charOut[MAX_CHAR_LINE_Y][MAX_CHAR_LINE_X], bool charIn[MAX_CHAR_LINE_Y][MAX_CHAR_LINE_X]) {
	for (int x = 0; x < MAX_CHAR_LINE_X; x++) {
		for (int y = 0; y < MAX_CHAR_LINE_Y; y++) {
			charOut[y][x] = charIn[y][x];
		}
	}
}

uint64_t returnChar(bool _char[MAX_CHAR_LINE_Y][MAX_CHAR_LINE_X], int64_t UTF_8) {
	switch (UTF_8) {
	case 'a': charCopy(_char, a);	return UTF_8;	break;
	case 'b': charCopy(_char, b);	return UTF_8;	break;
	case 'c': charCopy(_char, c);	return UTF_8;	break;
	case 'd': charCopy(_char, d);	return UTF_8;	break;
	case 'e': charCopy(_char, e);	return UTF_8;	break;
	case 'f': charCopy(_char, f);	return UTF_8;	break;
	case 'g': charCopy(_char, g);	return UTF_8;	break;
	case 'h': charCopy(_char, h);	return UTF_8;	break;
	case 'i': charCopy(_char, i);	return UTF_8;	break;
	case 'j': charCopy(_char, j);	return UTF_8;	break;
	case 'k': charCopy(_char, k);	return UTF_8;	break;
	case 'l': charCopy(_char, l);	return UTF_8;	break;
	case 'm': charCopy(_char, m);	return UTF_8;	break;
	case 'n': charCopy(_char, n);	return UTF_8;	break;
	case 'o': charCopy(_char, o);	return UTF_8;	break;
	case 'p': charCopy(_char, p);	return UTF_8;	break;
	case 'q': charCopy(_char, q);	return UTF_8;	break;
	case 'r': charCopy(_char, r);	return UTF_8;	break;
	case 's': charCopy(_char, s);	return UTF_8;	break;
	case 't': charCopy(_char, t);	return UTF_8;	break;
	case 'u': charCopy(_char, u);	return UTF_8;	break;
	case 'v': charCopy(_char, v);	return UTF_8;	break;
	case 'w': charCopy(_char, w);	return UTF_8;	break;
	case 'x': charCopy(_char, x);	return UTF_8;	break;
	case 'y': charCopy(_char, y);	return UTF_8;	break;
	case 'z': charCopy(_char, z);	return UTF_8;	break;

	case '0': charCopy(_char, rei);		return UTF_8;	break;
	case '1': charCopy(_char, ichi);	return UTF_8;	break;
	case '2': charCopy(_char, ni);		return UTF_8;	break;
	case '3': charCopy(_char, san);		return UTF_8;	break;
	case '4': charCopy(_char, yon);		return UTF_8;	break;
	case '5': charCopy(_char, go);		return UTF_8;	break;
	case '6': charCopy(_char, roku);	return UTF_8;	break;
	case '7': charCopy(_char, nana);	return UTF_8;	break;
	case '8': charCopy(_char, hachi);	return UTF_8;	break;
	case '9': charCopy(_char, kyuu);	return UTF_8;	break;

	case 0x0: charCopy(_char, null);		return UTF_8;	break;
	case '?': charCopy(_char, question);	return UTF_8;	break;
	case '.': charCopy(_char, dot);			return UTF_8;	break;
	case ',': charCopy(_char, come);		return UTF_8;	break;
	case ' ': charCopy(_char, space);		return UTF_8;	break;
	case '%': charCopy(_char, procent);		return UTF_8;	break;
	case '*': charCopy(_char, asterisk);	return UTF_8;	break;
	case '+': charCopy(_char, plus);		return UTF_8;	break;
	case '-': charCopy(_char, minus);		return UTF_8;	break;
	case '/': charCopy(_char, solidus);		return UTF_8;	break;
	case ':': charCopy(_char, colon);		return UTF_8;	break;

	default: return -1;
	}
}
