#include <stdint.h>
#include <stdbool.h>

#define MAX_CHAR_LINE_X		10
#define MAX_CHAR_LINE_Y		10

void charCopy(bool charOut[MAX_CHAR_LINE_Y][MAX_CHAR_LINE_X], bool charIn[MAX_CHAR_LINE_Y][MAX_CHAR_LINE_X]);
uint64_t returnChar(bool _char[MAX_CHAR_LINE_Y][MAX_CHAR_LINE_X], int64_t UTF_8);
