/*
 * STM32F1xx_ILI9225_176x220.h
 *
 *  Created on: 13 мар. 2026 г.
 *      Author: user
 */

#ifndef INC_STM32F1XX_ILI9225_176X220_H_
#define INC_STM32F1XX_ILI9225_176X220_H_

#include "main.h"

#include "stdint.h"
#include "stdbool.h"

struct SPI{
	uint16_t			RS_PIN;
	GPIO_TypeDef		*RS_PORT;

	uint16_t			CS_PIN;
	GPIO_TypeDef		*CS_PORT;

	uint16_t			RST_PIN;
	GPIO_TypeDef		*RST_PORT;
};
struct SPI SPI;

void SPI_move(SPI_HandleTypeDef * hspi, uint8_t hByte, uint8_t lByte);
void setRegistor(SPI_HandleTypeDef * hspi, uint16_t reg_hex);
void setCommand(SPI_HandleTypeDef * hspi, uint16_t cmd_hex);
void set_ReC(SPI_HandleTypeDef * hspi, uint16_t reg_hex, uint16_t cmd_hex);
void swap(uint16_t *a, uint16_t *b);

void LCD_Init(SPI_HandleTypeDef * hspi);
void LCD_setPixel(SPI_HandleTypeDef * hspi, unsigned int x, unsigned int y, uint16_t color);
void LCD_charOut(SPI_HandleTypeDef * hspi, int64_t char_UTF_8, unsigned int x, unsigned int y, uint16_t charColor, uint16_t bkColor);
void LCD_textOut(SPI_HandleTypeDef *hspi, unsigned int x, unsigned int y, char text[], unsigned int numCharInText, uint16_t charColor, uint16_t bkColor);
void LCD_line(SPI_HandleTypeDef * hspi, uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2, uint16_t color);
void LCD_circle(SPI_HandleTypeDef * hspi, uint8_t x0, uint8_t y0, uint8_t r, uint16_t color);

uint16_t RGB(uint8_t red8, uint8_t green8, uint8_t blue8);

#endif /* INC_STM32F1XX_ILI9225_176X220_H_ */
